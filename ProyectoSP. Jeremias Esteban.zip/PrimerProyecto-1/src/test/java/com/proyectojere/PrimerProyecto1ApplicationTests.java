package com.proyectojere;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrimerProyecto1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
